﻿using System;

namespace Farm
{
    public class StartUp
    {
        static void Main(string[] args)
        {
            
            Puppy pu=new Puppy();
            pu.Bark();
            pu.Eat();
            pu.Weep();
        }
    }
}
